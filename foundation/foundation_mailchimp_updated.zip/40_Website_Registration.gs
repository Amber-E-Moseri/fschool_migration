/***************************************
 * 40_Website_Registration.gs
 *
 * Website registration receiver for the
 * Typeform-style frontend.
 ***************************************/

const APPLICANTS_HEADERS_WEBSITE = [
  'Timestamp',
  'First Name',
  'Last Name',
  'Email',
  'Phone',
  'Fellowship Code',
  'Class Choice',
  'Born Again',
  'Speaks In Tongues',
  'Water Baptized',
  'Submitted At',
  'Source'
];

function doGet(e) {
  try {
    const action = String((e && e.parameter && e.parameter.action) || '').trim().toLowerCase();
    if (action) return doGetApi_(e);

    const resource = String((e && e.parameter && e.parameter.resource) || '').trim().toLowerCase();

    if (resource === 'fellowships') {
      return ContentService
        .createTextOutput(buildFellowshipsCsv_())
        .setMimeType(ContentService.MimeType.CSV);
    }

    if (resource === 'class_options') {
      return ContentService
        .createTextOutput(buildClassOptionsCsv_())
        .setMimeType(ContentService.MimeType.CSV);
    }

    return ContentService
      .createTextOutput(JSON.stringify({ ok: true, message: 'Website registration endpoint is live.' }))
      .setMimeType(ContentService.MimeType.JSON);
  } catch (err) {
    return ContentService
      .createTextOutput(JSON.stringify({ ok: false, error: err.message }))
      .setMimeType(ContentService.MimeType.JSON);
  }
}

function doPost(e) {
  try {
    const body = JSON.parse((e && e.postData && e.postData.contents) || '{}');

    const payload = {
      firstName: body.firstName || '',
      lastName: body.lastName || '',
      email: body.email || '',
      phone: body.phone || '',
      fellowshipCode: body.fellowshipCode || '',
      classChoice: body.classChoice || '',
      bornAgain: body.bornAgain || '',
      speaksInTongues: body.speaksInTongues || '',
      waterBaptized: body.waterBaptized || '',
      submittedAt: body.submittedAt || new Date().toISOString()
    };

    // Keep submission durable first: write to APPLICANTS before any external API.
    saveWebsiteRegistration_(payload);

    let mailchimpResult = { ok: false, reason: 'skipped' };
    try {
      mailchimpResult = subscribeToMailchimp_(payload);
    } catch (mailErr) {
      // Never break form submission for Mailchimp issues.
      logInfo('MAILCHIMP_SUBSCRIBE', 'Mailchimp call failed after sheet write', {
        error: String(mailErr && mailErr.message ? mailErr.message : mailErr)
      });
      mailchimpResult = { ok: false, reason: 'exception' };
    }

    return ContentService
      .createTextOutput(JSON.stringify({
        ok: true,
        mailchimpOk: !!mailchimpResult.ok,
        mailchimpReason: mailchimpResult.reason || ''
      }))
      .setMimeType(ContentService.MimeType.JSON);
  } catch (err) {
    return ContentService
      .createTextOutput(JSON.stringify({ ok: false, error: err.message }))
      .setMimeType(ContentService.MimeType.JSON);
  }
}

function subscribeToMailchimp_(payload) {
  const settings = getSettingsMap_();
  const enabled = parseBoolSetting_(settings.MAILCHIMP_ENABLED);
  if (!enabled) {
    logInfo('MAILCHIMP_SUBSCRIBE', 'Skipped (MAILCHIMP_ENABLED is not TRUE)');
    return { ok: false, reason: 'disabled' };
  }

  const apiKey = String(settings.MAILCHIMP_API_KEY || '').trim();
  const audienceId = String(settings.MAILCHIMP_AUDIENCE_ID || '').trim();
  const server = String(settings.MAILCHIMP_SERVER_PREFIX || '').trim().toLowerCase();
  const status = String(settings.MAILCHIMP_STATUS || 'subscribed').trim().toLowerCase();
  if (!apiKey || !audienceId || !server) {
    logInfo('MAILCHIMP_SUBSCRIBE', 'Skipped (missing MAILCHIMP settings)', {
      hasApiKey: !!apiKey,
      hasAudienceId: !!audienceId,
      hasServerPrefix: !!server
    });
    return { ok: false, reason: 'missing_config' };
  }

  const email = String(payload.email || '').trim().toLowerCase();
  if (!email) return { ok: false, reason: 'missing_email' };
  const subscriberHash = Utilities.computeDigest(Utilities.DigestAlgorithm.MD5, email)
    .map(function (b) {
      const v = (b < 0 ? b + 256 : b).toString(16);
      return v.length === 1 ? '0' + v : v;
    })
    .join('');
  const url = `https://${server}.api.mailchimp.com/3.0/lists/${audienceId}/members/${subscriberHash}`;
  const data = {
    email_address: email,
    status: status || 'subscribed',
    status_if_new: status || 'subscribed',
    merge_fields: {
      FNAME: payload.firstName,
      LNAME: payload.lastName,
      PHONE: payload.phone
    },
    tags: [
      payload.fellowshipCode,
      payload.classChoice
    ].filter(Boolean)
  };

  try {
    const response = UrlFetchApp.fetch(url, {
      method: 'put',
      contentType: 'application/json',
      headers: {
        Authorization: 'Bearer ' + apiKey
      },
      payload: JSON.stringify(data),
      muteHttpExceptions: true
    });
    const code = response.getResponseCode();
    const result = JSON.parse(response.getContentText() || '{}');
    if (code >= 200 && code < 300) {
      logInfo('MAILCHIMP_SUBSCRIBE', 'Success', { code: code, email: email, status: data.status_if_new });
      return { ok: true, reason: 'ok' };
    }
    if (result.status === 'subscribed' || !!result.id) {
      logInfo('MAILCHIMP_SUBSCRIBE', 'Success (member already existed or returned id)', { code: code, email: email });
      return { ok: true, reason: 'ok' };
    }
    logInfo('MAILCHIMP_SUBSCRIBE', 'Failed', {
      code: code,
      email: email,
      title: String(result.title || ''),
      detail: String(result.detail || '')
    });
    return { ok: false, reason: `http_${code}` };
  } catch (err) {
    logInfo('MAILCHIMP_SUBSCRIBE', 'Fetch exception', {
      email: email,
      error: String(err && err.message ? err.message : err)
    });
    return { ok: false, reason: 'fetch_error' };
  }
}

function getSettingsMap_() {
  const out = {};
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const sh = ss.getSheetByName('SETTINGS');
  if (!sh || sh.getLastRow() < 2) return out;

  const rows = sh.getRange(2, 1, sh.getLastRow() - 1, Math.max(sh.getLastColumn(), 2)).getValues();
  for (let i = 0; i < rows.length; i++) {
    const key = String(rows[i][0] || '').trim();
    if (!key) continue;
    out[key] = String(rows[i][1] || '').trim();
  }
  return out;
}

function parseBoolSetting_(v) {
  const s = String(v || '').trim().toLowerCase();
  return s === 'true' || s === '1' || s === 'yes' || s === 'y';
}

function buildFellowshipsCsv_() {
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_FELLOWSHIP_MAP_);
  if (!sheet) throw new Error('FELLOWSHIP_MAP sheet not found.');

  const rows = sheet.getDataRange().getValues();
  if (rows.length < 2) return 'label,value\n';

  const headers = rows[0].map(h => String(h || '').trim());
  const H = headerIndexLoose(headers);
  const labelIdx = H.campusname != null
    ? H.campusname
    : (H.campus_name != null
      ? H.campus_name
      : (H.campus != null
        ? H.campus
        : (H.label != null
          ? H.label
          : (H.fellowshipname != null
            ? H.fellowshipname
            : (H.fellowship != null ? H.fellowship : null)))));
  const valueIdx = H.value != null ? H.value : (H.fellowshipcode != null ? H.fellowshipcode : (H.code != null ? H.code : null));
  if (labelIdx == null || valueIdx == null) throw new Error('FELLOWSHIP_MAP needs label/value style columns.');

  const out = ['label,value'];
  for (let i = 1; i < rows.length; i++) {
    const label = csvEscape_(rows[i][labelIdx]);
    const value = csvEscape_(rows[i][valueIdx]);
    if (!String(label).trim() || !String(value).trim()) continue;
    out.push(`${label},${value}`);
  }
  return out.join('\n');
}

function buildClassOptionsCsv_() {
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_CLASS_OPTIONS);
  if (!sheet) throw new Error('CLASS_OPTIONS sheet not found.');

  const rows = sheet.getDataRange().getValues();
  if (rows.length < 2) return 'fellowship_code,class_id,teacher_id,teacher_name,day,time,active,class_start_date,teacher_email\n';

  const headers = rows[0].map(h => String(h || '').trim());
  const H = headerIndexLoose(headers);
  const fellowshipCodeIdx = H.fellowshipcode != null ? H.fellowshipcode : (H.groupid != null ? H.groupid : null);
  const classIdIdx = H.classid != null ? H.classid : (H.value != null ? H.value : null);
  const teacherIdIdx = H.teacherid != null ? H.teacherid : null;
  const teacherNameIdx = H.teachername != null ? H.teachername : null;
  const dayIdx = H.day != null ? H.day : null;
  const timeIdx = H.time != null ? H.time : null;
  const activeIdx = H.active != null ? H.active : null;
  const classStartDateIdx = H.classstartdate != null ? H.classstartdate : null;
  const teacherEmailIdx = H.teacheremail != null ? H.teacheremail : (H.email != null ? H.email : null);
  if (fellowshipCodeIdx == null || classIdIdx == null || dayIdx == null || timeIdx == null) {
    throw new Error('CLASS_OPTIONS needs FellowshipCode, ClassID, Day, and Time columns.');
  }

  const out = ['fellowship_code,class_id,teacher_id,teacher_name,day,time,active,class_start_date,teacher_email'];
  for (let i = 1; i < rows.length; i++) {
    const fellowshipCode = csvEscape_(rows[i][fellowshipCodeIdx]);
    const classId = csvEscape_(rows[i][classIdIdx]);
    const teacherId = csvEscape_(teacherIdIdx != null ? rows[i][teacherIdIdx] : '');
    const teacherName = csvEscape_(teacherNameIdx != null ? rows[i][teacherNameIdx] : '');
    const day = csvEscape_(rows[i][dayIdx]);
    const time = csvEscape_(rows[i][timeIdx]);
    const active = csvEscape_(activeIdx != null ? rows[i][activeIdx] : '');
    const classStartDate = csvEscape_(classStartDateIdx != null ? rows[i][classStartDateIdx] : '');
    const teacherEmail = csvEscape_(teacherEmailIdx != null ? rows[i][teacherEmailIdx] : '');
    if (!String(fellowshipCode).trim() || !String(classId).trim()) continue;
    out.push(`${fellowshipCode},${classId},${teacherId},${teacherName},${day},${time},${active},${classStartDate},${teacherEmail}`);
  }
  return out.join('\n');
}

function csvEscape_(v) {
  const s = String(v == null ? '' : v);
  if (/[",\n\r]/.test(s)) return `"${s.replace(/"/g, '""')}"`;
  return s;
}

function saveWebsiteRegistration_(data) {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const sheet = ss.getSheetByName(SHEET_APPLICANTS);

  if (!sheet) throw new Error('APPLICANTS sheet not found.');

  ensureApplicantsHeaders_(sheet);

  sheet.appendRow([
    new Date(),
    data.firstName,
    data.lastName,
    data.email,
    data.phone,
    data.fellowshipCode,
    data.classChoice,
    data.bornAgain,
    data.speaksInTongues,
    data.waterBaptized,
    data.submittedAt,
    'Website'
  ]);
}

function ensureApplicantsHeaders_(sheet) {
  const hasRows = sheet.getLastRow() > 0;
  if (!hasRows) {
    sheet.getRange(1, 1, 1, APPLICANTS_HEADERS_WEBSITE.length).setValues([APPLICANTS_HEADERS_WEBSITE]);
    return;
  }

  const existing = sheet
    .getRange(1, 1, 1, APPLICANTS_HEADERS_WEBSITE.length)
    .getValues()[0]
    .map(v => String(v || '').trim());

  const mismatch = APPLICANTS_HEADERS_WEBSITE.some((h, idx) => existing[idx] !== h);
  if (mismatch) {
    sheet.getRange(1, 1, 1, APPLICANTS_HEADERS_WEBSITE.length).setValues([APPLICANTS_HEADERS_WEBSITE]);
  }
}
